# Installation
> `npm install --save @types/source-list-map`

# Summary
This package contains type definitions for source-list-map (https://github.com/webpack/source-list-map.git).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/source-list-map

Additional Details
 * Last updated: Mon, 21 Aug 2017 22:03:22 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by e-cloud <https://github.com/e-cloud>.
