# Installation
> `npm install --save @types/webpack-sources`

# Summary
This package contains type definitions for webpack-sources (https://github.com/webpack/webpack-sources).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/webpack-sources

Additional Details
 * Last updated: Fri, 29 Jun 2018 03:18:45 GMT
 * Dependencies: crypto, source-map, source-list-map, node
 * Global values: none

# Credits
These definitions were written by e-cloud <https://github.com/e-cloud>, Chris Eppstein <https://github.com/chriseppstein>.
