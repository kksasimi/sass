import * as tslib_1 from "tslib";
/**
 * Created by vadimdez on 01/11/2016.
 */
import { NgModule } from '@angular/core';
import { PdfViewerComponent } from './pdf-viewer.component';
var PdfViewerModule = /** @class */ (function () {
    function PdfViewerModule() {
    }
    PdfViewerModule = tslib_1.__decorate([
        NgModule({
            declarations: [PdfViewerComponent],
            exports: [PdfViewerComponent]
        })
    ], PdfViewerModule);
    return PdfViewerModule;
}());
export { PdfViewerModule };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGRmLXZpZXdlci5tb2R1bGUuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9uZzItcGRmLXZpZXdlci8iLCJzb3VyY2VzIjpbInNyYy9hcHAvcGRmLXZpZXdlci9wZGYtdmlld2VyLm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7O0dBRUc7QUFDSCxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRXpDLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLHdCQUF3QixDQUFDO0FBcUI1RDtJQUFBO0lBQThCLENBQUM7SUFBbEIsZUFBZTtRQUozQixRQUFRLENBQUM7WUFDUixZQUFZLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQztZQUNsQyxPQUFPLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQztTQUM5QixDQUFDO09BQ1csZUFBZSxDQUFHO0lBQUQsc0JBQUM7Q0FBQSxBQUEvQixJQUErQjtTQUFsQixlQUFlIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBDcmVhdGVkIGJ5IHZhZGltZGV6IG9uIDAxLzExLzIwMTYuXG4gKi9cbmltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IFBkZlZpZXdlckNvbXBvbmVudCB9IGZyb20gJy4vcGRmLXZpZXdlci5jb21wb25lbnQnO1xuaW1wb3J0IHsgUERGSlNTdGF0aWMgfSBmcm9tICdwZGZqcy1kaXN0JztcblxuZGVjbGFyZSBnbG9iYWwge1xuICBjb25zdCBQREZKUzogUERGSlNTdGF0aWM7XG59XG5cbmV4cG9ydCB7XG4gIFBERkpTU3RhdGljLFxuICBQREZEb2N1bWVudFByb3h5LFxuICBQREZWaWV3ZXJQYXJhbXMsXG4gIFBERlBhZ2VQcm94eSxcbiAgUERGU291cmNlLFxuICBQREZQcm9ncmVzc0RhdGEsXG4gIFBERlByb21pc2Vcbn0gZnJvbSAncGRmanMtZGlzdCc7XG5cbkBOZ01vZHVsZSh7XG4gIGRlY2xhcmF0aW9uczogW1BkZlZpZXdlckNvbXBvbmVudF0sXG4gIGV4cG9ydHM6IFtQZGZWaWV3ZXJDb21wb25lbnRdXG59KVxuZXhwb3J0IGNsYXNzIFBkZlZpZXdlck1vZHVsZSB7fVxuIl19