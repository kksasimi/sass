export declare function _createEventBus(pdfJsViewer: any): any;
export declare const createEventBus: typeof _createEventBus;
